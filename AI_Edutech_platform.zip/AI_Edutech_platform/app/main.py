from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List
import uuid
from .models import Student, Question, LearningPath
from .ai_engine import AIEngine
from .database import db

app = FastAPI(title="AI Learning Platform")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

ai_engine = AIEngine()

@app.get("/")
async def root():
    return {"message": "AI Learning Platform API", "status": "running"}

@app.post("/api/student/register")
async def register_student(name: str, subject: str):
    student_id = str(uuid.uuid4())
    student = Student(id=student_id, name=name)
    db.create_student(student)
    return {
        "student_id": student_id, 
        "name": name,
        "subject": subject,
        "message": "Registration successful"
    }

@app.post("/api/assessment/initial")
async def initial_assessment(student_id: str, answers: dict):
    """Assess student's initial knowledge level"""
    student = db.get_student(student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    # Simple scoring logic
    score = sum(1 for ans in answers.values() if ans.get('correct', False))
    total = len(answers)
    percentage = (score / total) * 100
    
    # Determine level
    if percentage >= 70:
        level = "advanced"
    elif percentage >= 40:
        level = "intermediate"
    else:
        level = "beginner"
    
    # Update student level
    db.update_student(student_id, {"knowledge_level": level})
    
    # Identify weak areas
    weak_areas = [topic for topic, ans in answers.items() if not ans.get('correct', False)]
    
    # Save assessment result
    db.save_quiz_result(student_id, {
        "type": "initial_assessment",
        "score": score,
        "total": total,
        "percentage": percentage,
        "level": level
    })
    
    return {
        "score": score,
        "total": total,
        "percentage": percentage,
        "level": level,
        "weak_areas": weak_areas
    }

@app.post("/api/learning-path/generate")
async def generate_learning_path(student_id: str, subject: str, weak_areas: List[str]):
    """Generate personalized learning path"""
    student = db.get_student(student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    # Generate path using AI
    path_data = ai_engine.generate_learning_path(
        student.knowledge_level, 
        subject, 
        weak_areas
    )
    
    # Create and save learning path
    learning_path = LearningPath(
        student_id=student_id,
        topics=path_data.get("topics", []),
        estimated_duration=path_data.get("estimated_duration", "Unknown"),
        difficulty_progression=path_data.get("difficulty_progression", [])
    )
    
    db.save_learning_path(student_id, learning_path)
    
    return path_data

@app.get("/api/learning-path/{student_id}")
async def get_learning_path(student_id: str):
    """Get student's learning path"""
    path = db.get_learning_path(student_id)
    if not path:
        raise HTTPException(status_code=404, detail="Learning path not found")
    return path

@app.post("/api/quiz/generate")
async def generate_quiz(topic: str, difficulty: str, num_questions: int = 5):
    """Generate adaptive quiz"""
    questions = ai_engine.generate_adaptive_quiz(topic, difficulty, num_questions)
    return {"questions": questions, "topic": topic, "difficulty": difficulty}

@app.post("/api/quiz/submit")
async def submit_quiz(student_id: str, topic: str, score: float, total: int):
    """Submit quiz results"""
    student = db.get_student(student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    percentage = (score / total) * 100
    
    # Save quiz result
    db.save_quiz_result(student_id, {
        "type": "topic_quiz",
        "topic": topic,
        "score": score,
        "total": total,
        "percentage": percentage
    })
    
    # Update progress
    db.update_progress(student_id, topic, score)
    
    # Update student's completed topics if passed
    if percentage >= 60:
        student.completed_topics.append(topic)
        db.update_student(student_id, {"completed_topics": student.completed_topics})
    
    return {
        "message": "Quiz submitted successfully",
        "score": score,
        "total": total,
        "percentage": percentage,
        "passed": percentage >= 60
    }

@app.post("/api/tutor/ask")
async def ask_tutor(student_id: str, question: str, context: str = ""):
    """AI tutor chat endpoint"""
    student = db.get_student(student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    response = ai_engine.ai_tutor_response(question, context)
    return {"answer": response, "student_level": student.knowledge_level}

@app.get("/api/student/{student_id}/progress")
async def get_progress(student_id: str):
    """Get student progress"""
    student = db.get_student(student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    progress = db.get_progress(student_id)
    
    return {
        "name": student.name,
        "level": student.knowledge_level,
        "completed_topics": student.completed_topics,
        "topics_completed_count": len(student.completed_topics),
        "quizzes_taken": progress["quizzes_taken"] if progress else 0,
        "last_active": progress["last_active"] if progress else None
    }

@app.get("/api/student/{student_id}/analytics")
async def get_analytics(student_id: str):
    """Get detailed student analytics"""
    student = db.get_student(student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    
    analytics = db.get_student_analytics(student_id)
    return analytics

@app.delete("/api/student/{student_id}")
async def delete_student(student_id: str):
    """Delete student (for demo reset)"""
    if student_id in db.students:
        del db.students[student_id]
        if student_id in db.learning_paths:
            del db.learning_paths[student_id]
        if student_id in db.quiz_results:
            del db.quiz_results[student_id]
        if student_id in db.student_progress:
            del db.student_progress[student_id]
        return {"message": "Student deleted successfully"}
    raise HTTPException(status_code=404, detail="Student not found")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


