from typing import Dict, Optional
from datetime import datetime
from .models import Student, LearningPath

class Database:
    def __init__(self):
        self.students: Dict[str, Student] = {}
        self.learning_paths: Dict[str, LearningPath] = {}
        self.quiz_results: Dict[str, list] = {}
        self.student_progress: Dict[str, dict] = {}
    
    def create_student(self, student: Student):
        self.students[student.id] = student
        return student
    
    def get_student(self, student_id: str) -> Optional[Student]:
        return self.students.get(student_id)
    
    def update_student(self, student_id: str, updates: dict):
        if student_id in self.students:
            student = self.students[student_id]
            for key, value in updates.items():
                setattr(student, key, value)
            return student
        return None
    
    def save_learning_path(self, student_id: str, path: LearningPath):
        self.learning_paths[student_id] = path
        return path
    
    def get_learning_path(self, student_id: str) -> Optional[LearningPath]:
        return self.learning_paths.get(student_id)
    
    def save_quiz_result(self, student_id: str, result: dict):
        if student_id not in self.quiz_results:
            self.quiz_results[student_id] = []
        result['timestamp'] = datetime.now()
        self.quiz_results[student_id].append(result)
    
    def update_progress(self, student_id: str, topic: str, score: float):
        if student_id not in self.student_progress:
            self.student_progress[student_id] = {
                "quizzes_taken": 0,
                "last_active": None,
                "topic_scores": {}
            }
        
        progress = self.student_progress[student_id]
        progress["quizzes_taken"] += 1
        progress["last_active"] = datetime.now()
        progress["topic_scores"][topic] = score
    
    def get_progress(self, student_id: str) -> Optional[dict]:
        return self.student_progress.get(student_id)
    
    def get_student_analytics(self, student_id: str) -> dict:
        student = self.get_student(student_id)
        quiz_results = self.quiz_results.get(student_id, [])
        progress = self.get_progress(student_id)
        
        return {
            "student_name": student.name if student else "Unknown",
            "level": student.knowledge_level if student else "beginner",
            "total_quizzes": len(quiz_results),
            "completed_topics": len(student.completed_topics) if student else 0,
            "quiz_history": quiz_results,
            "progress": progress
        }

# Create global database instance
db = Database()