from openai import OpenAI
import os
from typing import List
import json
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

class AIEngine:
    
    @staticmethod
    def generate_learning_path(student_level: str, subject: str, weak_areas: List[str]):
        prompt = f"""
        Create a personalized learning path for a {student_level} student studying {subject}.
        Weak areas: {', '.join(weak_areas) if weak_areas else 'None identified'}
        
        Return ONLY a valid JSON object (no markdown, no backticks) with:
        {{
          "topics": ["topic1", "topic2", ...],
          "estimated_duration": "X weeks",
          "difficulty_progression": ["beginner", "intermediate", ...]
        }}
        
        Focus on addressing weak areas first. Include 5-7 topics.
        """
        
        try:
            response = client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an expert educational content creator. Always respond with valid JSON only."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7
            )
            
            content = response.choices[0].message.content.strip()
            # Remove markdown code blocks if present
            if content.startswith("```"):
                content = content.split("```")[1]
                if content.startswith("json"):
                    content = content[4:]
            
            return json.loads(content)
        except Exception as e:
            # Fallback response
            return {
                "topics": [
                    f"Introduction to {subject}",
                    f"Fundamentals of {subject}",
                    f"Intermediate {subject} Concepts",
                    f"Advanced {subject} Topics",
                    f"{subject} Practice Problems"
                ],
                "estimated_duration": "4-6 weeks",
                "difficulty_progression": ["beginner", "beginner", "intermediate", "intermediate", "advanced"]
            }
    
    @staticmethod
    def generate_adaptive_quiz(topic: str, difficulty: str, num_questions: int = 5):
        prompt = f"""
        Generate {num_questions} multiple-choice questions about "{topic}" at {difficulty} difficulty level.
        
        Return ONLY a valid JSON array (no markdown, no backticks):
        [
          {{
            "question": "question text",
            "options": ["option1", "option2", "option3", "option4"],
            "correct_answer": "option2",
            "difficulty": "{difficulty}"
          }}
        ]
        
        Make questions practical and educational.
        """
        
        try:
            response = client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an expert quiz creator. Always respond with valid JSON only."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.8
            )
            
            content = response.choices[0].message.content.strip()
            # Remove markdown code blocks if present
            if content.startswith("```"):
                content = content.split("```")[1]
                if content.startswith("json"):
                    content = content[4:]
            
            return json.loads(content)
        except Exception as e:
            # Fallback response
            return [
                {
                    "question": f"What is a key concept in {topic}?",
                    "options": ["Option A", "Option B", "Option C", "Option D"],
                    "correct_answer": "Option B",
                    "difficulty": difficulty
                }
            ] * num_questions
    
    @staticmethod
    def ai_tutor_response(student_question: str, context: str = ""):
        prompt = f"""
        You are a friendly and knowledgeable AI tutor. 
        
        Student asks: "{student_question}"
        
        Context: {context if context else 'General question'}
        
        Provide a clear, encouraging explanation. Use examples and break down complex concepts.
        Be conversational and supportive.
        """
        
        try:
            response = client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an encouraging AI tutor who makes learning engaging and accessible."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7
            )
            
            return response.choices[0].message.content
        except Exception as e:
            return "I'm having trouble connecting right now. Could you rephrase your question or try again?"