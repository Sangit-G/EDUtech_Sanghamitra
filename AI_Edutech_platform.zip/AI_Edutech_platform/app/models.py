from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class Student(BaseModel):
    id: str
    name: str
    knowledge_level: str = "beginner"
    completed_topics: List[str] = []
    created_at: datetime = datetime.now()

class Question(BaseModel):
    question: str
    options: List[str]
    correct_answer: str
    difficulty: str

class LearningPath(BaseModel):
    student_id: str
    topics: List[str]
    estimated_duration: str
    difficulty_progression: List[str]
    created_at: datetime = datetime.now()